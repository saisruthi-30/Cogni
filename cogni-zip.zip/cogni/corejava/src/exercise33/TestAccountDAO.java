package exercise33;


public class TestAccountDAO {
    public static void main(String[] args) {
        AccountDAO dao = new AccountDAO();

        System.out.println("Before transfer:");
        dao.printAllAccounts();

        dao.transferMoney(1, 2, 200.0); // From Alice to Bob

        System.out.println("After transfer:");
        dao.printAllAccounts();
    }
}

