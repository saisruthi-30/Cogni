package exercise33;

import java.sql.*;

public class AccountDAO {
    private static final String DB_URL = "jdbc:sqlite:C:/Users/ADMIN/Desktop/cogni/cog-sql/students.db";

    public void transferMoney(int fromId, int toId, double amount) {
        String debitSql = "UPDATE accounts SET balance = balance - ? WHERE id = ?";
        String creditSql = "UPDATE accounts SET balance = balance + ? WHERE id = ?";

        try (Connection conn = DriverManager.getConnection(DB_URL)) {
            conn.setAutoCommit(false); // Begin transaction

            try (PreparedStatement debitStmt = conn.prepareStatement(debitSql);
                 PreparedStatement creditStmt = conn.prepareStatement(creditSql)) {

                // Debit
                debitStmt.setDouble(1, amount);
                debitStmt.setInt(2, fromId);
                debitStmt.executeUpdate();

                // Credit
                creditStmt.setDouble(1, amount);
                creditStmt.setInt(2, toId);
                creditStmt.executeUpdate();

                // Commit if both succeed
                conn.commit();
                System.out.println("Transaction successful: Transferred " + amount);

            } catch (SQLException e) {
                conn.rollback();
                System.err.println("Transaction failed. Rolled back. " + e.getMessage());
            } finally {
                conn.setAutoCommit(true); // Reset auto-commit
            }

        } catch (SQLException e) {
            System.err.println("Database error: " + e.getMessage());
        }
    }

    // Utility to show balances
    public void printAllAccounts() {
        String sql = "SELECT * FROM accounts";
        try (Connection conn = DriverManager.getConnection(DB_URL);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                System.out.println("ID: " + rs.getInt("id") +
                                   ", Name: " + rs.getString("name") +
                                   ", Balance: " + rs.getDouble("balance"));
            }

        } catch (SQLException e) {
            System.err.println("Error fetching accounts: " + e.getMessage());
        }
    }
}
