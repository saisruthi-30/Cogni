package exercises;

public class Exercise12 {
    public static int add(int a, int b) {
        return a + b;
    }

    public static double add(double a, double b) {
        return a + b;
    }

    public static int add(int a, int b, int c) {
        return a + b + c;
    }

    public static void main(String[] args) {
        System.out.println("add(int, int): " + add(10, 20));
        System.out.println("add(double, double): " + add(10.5, 5.5));
        System.out.println("add(int, int, int): " + add(1, 2, 3));
    }
}
