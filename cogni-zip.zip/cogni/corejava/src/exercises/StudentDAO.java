package exercises;

import java.sql.*;

public class StudentDAO {
    private static final String DB_URL = "jdbc:sqlite:C:/Users/ADMIN/Desktop/cogni/cog-sql/students.db";

    // Insert new student
    public void insertStudent(String name, int age) {
        String sql = "INSERT INTO students(name, age) VALUES (?, ?)";

        try (Connection conn = DriverManager.getConnection(DB_URL);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, name);
            pstmt.setInt(2, age);

            int rows = pstmt.executeUpdate();
            System.out.println("Inserted " + rows + " row(s) successfully.");

        } catch (SQLException e) {
            System.err.println("Insert failed: " + e.getMessage());
        }
    }

    // Update student age by id
    public void updateStudentAge(int id, int newAge) {
        String sql = "UPDATE students SET age = ? WHERE id = ?";

        try (Connection conn = DriverManager.getConnection(DB_URL);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, newAge);
            pstmt.setInt(2, id);

            int rows = pstmt.executeUpdate();
            System.out.println("Updated " + rows + " row(s) successfully.");

        } catch (SQLException e) {
            System.err.println("Update failed: " + e.getMessage());
        }
    }

    // Optional: Fetch all students to verify changes
    public void printAllStudents() {
        String sql = "SELECT * FROM students";

        try (Connection conn = DriverManager.getConnection(DB_URL);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                System.out.println("ID: " + rs.getInt("id") +
                                   ", Name: " + rs.getString("name") +
                                   ", Age: " + rs.getInt("age"));
            }

        } catch (SQLException e) {
            System.err.println("Query failed: " + e.getMessage());
        }
    }
}
