package exercises;

import java.io.*;
import java.net.*;

public class ChatClient {
    public static void main(String[] args) {
        try (Socket socket = new Socket("localhost", 5000)) {
            System.out.println("Connected to server.");

            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
            BufferedReader keyboard = new BufferedReader(new InputStreamReader(System.in));

            String message;
            while (true) {
                System.out.print("You: ");
                message = keyboard.readLine();
                out.println(message);

                if (message.equalsIgnoreCase("bye")) {
                    break;
                }

                String reply = in.readLine();
                if (reply == null) {
                    break;
                }
                System.out.println("Server: " + reply);
            }

            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
