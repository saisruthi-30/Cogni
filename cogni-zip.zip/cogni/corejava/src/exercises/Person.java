package exercises;

public class Person {

}
