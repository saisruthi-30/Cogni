//package exercises;
//
//public class Exercise30 {
//
//    public static void checkObjectType(Object obj) {
//        switch (obj) {
//            case Integer i -> System.out.println("Integer with value: " + i);
//            case String s -> System.out.println("String with value: " + s);
//            case Double d -> System.out.println("Double with value: " + d);
//            case null -> System.out.println("Object is null");
//            default -> System.out.println("Unknown type");
//        }
//    }
//
//    public static void main(String[] args) {
//        checkObjectType(100);
//        checkObjectType("Hello");
//        checkObjectType(3.14);
//        checkObjectType(true);
//        checkObjectType(null);
//    }
//}
package exercises;

public class Exercise30 {

    public static void checkObjectType(Object obj) {
        if (obj == null) {
            System.out.println("Object is null");
        } else if (obj instanceof Integer) {
            Integer i = (Integer) obj;
            System.out.println("Integer with value: " + i);
        } else if (obj instanceof String) {
            String s = (String) obj;
            System.out.println("String with value: " + s);
        } else if (obj instanceof Double) {
            Double d = (Double) obj;
            System.out.println("Double with value: " + d);
        } else {
            System.out.println("Unknown type: " + obj.getClass().getSimpleName());
        }
    }

    public static void main(String[] args) {
        checkObjectType(100);
        checkObjectType("Hello");
        checkObjectType(3.14);
        checkObjectType(true);
        checkObjectType(null);
    }
}
