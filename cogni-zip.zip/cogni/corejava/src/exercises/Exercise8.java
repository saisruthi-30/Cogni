package exercises;

public class Exercise8 {
    public static void main(String[] args) {
        int result1 = 10 + 5 * 2;         // Multiplication happens before addition
        int result2 = (10 + 5) * 2;       // Parentheses change the order
        int result3 = 100 / 5 + 2 * 3;    // Division and multiplication evaluated left to right
        int result4 = 100 / (5 + 5) * 2;  // Parentheses alter precedence

        System.out.println("10 + 5 * 2 = " + result1);         // 20
        System.out.println("(10 + 5) * 2 = " + result2);       // 30
        System.out.println("100 / 5 + 2 * 3 = " + result3);    // 20 + 6 = 26
        System.out.println("100 / (5 + 5) * 2 = " + result4);  // 100 / 10 * 2 = 20
    }
}
