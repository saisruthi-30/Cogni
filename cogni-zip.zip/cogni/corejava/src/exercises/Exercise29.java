//package exercises;
//
//import java.util.List;
//import java.util.stream.Collectors;
//
//public class Exercise29 {
//
//    // Define a record Person with name and age
//    public static record Person(String name, int age) {}
//
//    public static void main(String[] args) {
//        // Create instances of Person
//        Person p1 = new Person("Alice", 30);
//        Person p2 = new Person("Bob", 22);
//        Person p3 = new Person("Charlie", 28);
//        Person p4 = new Person("Diana", 19);
//
//        // Print individual records
//        System.out.println(p1);
//        System.out.println(p2);
//        System.out.println(p3);
//        System.out.println(p4);
//
//        // Create a List of Person
//        List<Person> people = List.of(p1, p2, p3, p4);
//
//        // Filter people aged 25 and above using Streams
//        List<Person> filtered = people.stream()
//                .filter(person -> person.age() >= 25)
//                .collect(Collectors.toList());
//
//        System.out.println("\nPeople aged 25 and above:");
//        filtered.forEach(System.out::println);
//    }
//}
package exercises;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Exercise29 {
    public static class Person {
        private String name;
        private int age;

        public Person(String name, int age) {
            this.name = name;
            this.age = age;
        }

        public String getName() {
            return name;
        }

        public int getAge() {
            return age;
        }

        @Override
        public String toString() {
            return "Person{name='" + name + "', age=" + age + "}";
        }
    }

    public static void main(String[] args) {
        List<Person> people = Arrays.asList(
            new Person("Alice", 30),
            new Person("Bob", 25),
            new Person("Charlie", 35)
        );

        // Print all persons
        for (Person p : people) {
            System.out.println(p);
        }

        // Filter persons whose age > 28 using Stream API
        List<Person> filtered = people.stream()
            .filter(p -> p.getAge() > 28)
            .collect(Collectors.toList());

        System.out.println("Filtered:");
        for (Person p : filtered) {
            System.out.println(p);
        }
    }
}

