package exercises;

public class Myclass39 {
    public void sayHello(String name) {
        System.out.println("Hello, " + name + "!");
    }

    public int add(int a, int b) {
        return a + b;
    }
}
