package exercises;

public class Exercise37 {
    public int square(int x) {
        return x * x;
    }

    public static void main(String[] args) {
        Exercise37 ex = new Exercise37();
        System.out.println("Square of 5: " + ex.square(5));
    }
}
