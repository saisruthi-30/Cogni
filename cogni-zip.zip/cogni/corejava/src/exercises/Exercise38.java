package exercises;

public class Exercise38 {
    private String greet(String name) {
        return "Hello, " + name + "!";
    }

    public static void main(String[] args) {
        Exercise38 ex = new Exercise38();
        System.out.println(ex.greet("World"));
    }
}
