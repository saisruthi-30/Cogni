package exercises;

import java.util.concurrent.CountDownLatch;

public class Exercise40 {
    public static void main(String[] args) throws InterruptedException {
        int totalThreads = 100_000;
        CountDownLatch latch = new CountDownLatch(totalThreads);

        long start = System.currentTimeMillis();

        for (int i = 0; i < totalThreads; i++) {
            int threadNum = i; // effectively final
            Thread.startVirtualThread(() -> {
                // Print only for the first 10 threads
                if (threadNum < 10) {
                    System.out.println("Hello from virtual thread #" + threadNum);
                }
                latch.countDown();
            });
        }

        latch.await(); // Wait for all threads to complete

        long end = System.currentTimeMillis();
        System.out.println("Launched and completed " + totalThreads + " virtual threads in " + (end - start) + " ms");
    }
}
