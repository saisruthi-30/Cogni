package exercises;

public class Exercise26 extends Thread {

    private String threadName;

    public Exercise26(String name) {
        this.threadName = name;
    }

    @Override
    public void run() {
        for(int i = 1; i <= 5; i++) {
            System.out.println(threadName + " is running: " + i);
            try {
                Thread.sleep(500);  // Sleep for 500 milliseconds to simulate work
            } catch (InterruptedException e) {
                System.out.println(threadName + " interrupted.");
            }
        }
    }

    public static void main(String[] args) {
        Exercise26 thread1 = new Exercise26("Thread 1");
        Exercise26 thread2 = new Exercise26("Thread 2");

        thread1.start();
        thread2.start();
    }
}
