package exercises;

public class Exercise7 {
    public static void main(String[] args) {
        // Implicit casting: int to double
        int intVal = 42;
        double doubleFromInt = intVal;

        // Explicit casting: double to int
        double doubleVal = 42.75;
        int intFromDouble = (int) doubleVal;

        System.out.println("Original int: " + intVal);
        System.out.println("Converted to double: " + doubleFromInt);

        System.out.println("Original double: " + doubleVal);
        System.out.println("Converted to int (explicit cast): " + intFromDouble);
    }
}
