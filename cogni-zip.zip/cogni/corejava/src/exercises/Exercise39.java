package exercises;

import java.lang.reflect.Method;
import java.lang.reflect.Parameter;

public class Exercise39 {
    public static void main(String[] args) {
        try {
            // Load the class dynamically
            Class<?> clazz = Class.forName("exercises.Myclass39");

            // Create an instance
            Object obj = clazz.getDeclaredConstructor().newInstance();

            // Get all declared methods
            Method[] methods = clazz.getDeclaredMethods();

            // Print method names and parameters
            for (Method method : methods) {
                System.out.print("Method: " + method.getName() + "(");
                Parameter[] parameters = method.getParameters();
                for (int i = 0; i < parameters.length; i++) {
                    System.out.print(parameters[i].getType().getSimpleName());
                    if (i < parameters.length - 1) System.out.print(", ");
                }
                System.out.println(")");
            }

            // Invoke sayHello method
            Method sayHelloMethod = clazz.getDeclaredMethod("sayHello", String.class);
            sayHelloMethod.invoke(obj, "Reflection");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
