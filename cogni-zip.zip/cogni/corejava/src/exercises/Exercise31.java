package exercises;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Exercise31 {
    public static void main(String[] args) {
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;

        try {
            // Load the SQLite JDBC driver
            Class.forName("org.sqlite.JDBC");

            // Connect to the database (use the full path or relative path)
            String dbURL = "jdbc:sqlite:C:/Users/ADMIN/Desktop/cogni/cog-sql/students.db";
            connection = DriverManager.getConnection(dbURL);

            // Create a statement
            statement = connection.createStatement();

            // Execute a query to get all students
            String query = "SELECT * FROM students";
            resultSet = statement.executeQuery(query);

            // Process the result set
            System.out.println("Student Records:");
            while (resultSet.next()) {
                int id = resultSet.getInt("id");  // Adjust column names as per your table
                String name = resultSet.getString("name");
                int age = resultSet.getInt("age");

                System.out.println("ID: " + id + ", Name: " + name + ", Age: " + age);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try { if (resultSet != null) resultSet.close(); } catch (Exception e) { }
            try { if (statement != null) statement.close(); } catch (Exception e) { }
            try { if (connection != null) connection.close(); } catch (Exception e) { }
        }
    }
}
