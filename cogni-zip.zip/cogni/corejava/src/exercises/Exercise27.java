package exercises;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Exercise27 {

    public static void main(String[] args) {
        List<String> names = new ArrayList<>();
        names.add("Zara");
        names.add("Alex");
        names.add("John");
        names.add("Mia");
        names.add("Chris");

        System.out.println("Before sorting: " + names);

        // Sort using lambda expression
        Collections.sort(names, (s1, s2) -> s1.compareTo(s2));

        System.out.println("After sorting: " + names);
    }
}
