//package exercises;
//
//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.SQLException;
//import java.sql.Statement;
//
//public class CreateDatabase {
//    public static void main(String[] args) {
//        // Path to your database file
//        String url = "jdbc:sqlite:C:/Users/ADMIN/Desktop/cogni/cog-sql/students.db";
//
//        // SQL to create students table
//        String createTableSQL = """
//            CREATE TABLE IF NOT EXISTS students (
//                id INTEGER PRIMARY KEY AUTOINCREMENT,
//                name TEXT NOT NULL,
//                age INTEGER,
//                course TEXT
//            );
//        """;
//
//        // SQL to insert dummy data
//        String insertDataSQL = """
//            INSERT INTO students (name, age, course) VALUES
//            ('Alice', 20, 'Java'),
//            ('Bob', 22, 'Python'),
//            ('Charlie', 21, 'C++');
//        """;
//
//        try {
//            // Load SQLite JDBC driver
//            Class.forName("org.sqlite.JDBC");
//
//            // Connect to the database (creates the file if it doesn't exist)
//            Connection conn = DriverManager.getConnection(url);
//            Statement stmt = conn.createStatement();
//
//            // Create table
//            stmt.execute(createTableSQL);
//
//            // Insert data
//            stmt.execute(insertDataSQL);
//
//            System.out.println("Database and table created, data inserted successfully!");
//
//            stmt.close();
//            conn.close();
//        } catch (ClassNotFoundException e) {
//            System.out.println("SQLite JDBC driver not found. Make sure the .jar is added to the project.");
//            e.printStackTrace();
//        } catch (SQLException e) {
//            System.out.println("SQL error occurred.");
//            e.printStackTrace();
//        }
//    }
//}
