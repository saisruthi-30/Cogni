package exercises;

import java.util.concurrent.*;
import java.util.*;

public class Exercise41 {
    public static void main(String[] args) {
        // Create a fixed thread pool with 3 threads
        ExecutorService executor = Executors.newFixedThreadPool(3);

        // Create a list of Callable tasks
        List<Callable<String>> callables = new ArrayList<>();
        for (int i = 1; i <= 5; i++) {
            int taskId = i;
            callables.add(() -> {
                Thread.sleep(1000); // Simulate delay
                return "Result from Task " + taskId;
            });
        }

        try {
            // Submit tasks and collect Future objects
            List<Future<String>> futures = new ArrayList<>();
            for (Callable<String> task : callables) {
                futures.add(executor.submit(task));
            }

            // Retrieve and print results from Futures
            for (Future<String> future : futures) {
                System.out.println(future.get()); // .get() blocks until result is ready
            }
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        } finally {
            executor.shutdown(); // Always shut down the executor
        }
    }
}
