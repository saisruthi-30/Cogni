package exercises;

public class Exercise6 {
    public static void main(String[] args) {
        int myInt = 100;
        float myFloat = 10.5f;
        double myDouble = 99.99;
        char myChar = 'A';
        boolean myBoolean = true;

        System.out.println("int value: " + myInt);
        System.out.println("float value: " + myFloat);
        System.out.println("double value: " + myDouble);
        System.out.println("char value: " + myChar);
        System.out.println("boolean value: " + myBoolean);
    }
}
