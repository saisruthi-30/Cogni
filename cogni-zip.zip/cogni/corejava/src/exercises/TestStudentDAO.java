package exercises;

public class TestStudentDAO {
    public static void main(String[] args) {
        StudentDAO dao = new StudentDAO();

        // Insert new students
        dao.insertStudent("David", 23);
        dao.insertStudent("Eva", 19);

        // Update student age
        dao.updateStudentAge(1, 25);  // Assuming student with id=1 exists

        // Print all students to verify
        dao.printAllStudents();
    }
}
