// 1. JavaScript Basics & Setup
console.log("Welcome to the Community Portal");

window.onload = () => {
  alert("Page fully loaded");
};

// 2. Syntax, Data Types, and Operators
const eventName = "Coding Workshop";
const eventDate = "2025-06-01";
let availableSeats = 25;

const eventInfo = `Event: ${eventName}, Date: ${eventDate}, Seats: ${availableSeats}`;
console.log(eventInfo);

// User registers
availableSeats--;
console.log(`Seats remaining: ${availableSeats}`);

// 3. Conditionals, Loops, Error Handling
const events = [
  { name: "Music Night", date: "2025-06-10", seats: 10 },
  { name: "Past Event", date: "2024-01-01", seats: 5 },
  { name: "Full Event", date: "2025-07-01", seats: 0 },
];

events.forEach(event => {
  const isFuture = new Date(event.date) > new Date();
  if (isFuture && event.seats > 0) {
    console.log(`${event.name} is open for registration`);
  } else {
    console.log(`${event.name} is not available`);
  }
});

function register(event) {
  try {
    if (event.seats <= 0) throw new Error("No seats available!");
    event.seats--;
    console.log(`Registered for ${event.name}`);
  } catch (err) {
    console.error(err.message);
  }
}

// 4. Functions, Closures, HOFs
function addEvent(events, newEvent) {
  events.push(newEvent);
}

function registerUser(event) {
  if (event.seats > 0) {
    event.seats--;
    console.log(`Registered for ${event.name}`);
  }
}

function filterEventsByCategory(events, category) {
  return events.filter(e => e.category === category);
}

// Closure to track category registrations
function createCategoryTracker() {
  const registrations = {};
  return function (category) {
    registrations[category] = (registrations[category] || 0) + 1;
    console.log(`Total registrations in ${category}: ${registrations[category]}`);
  };
}

const track = createCategoryTracker();
track("music");
track("tech");
track("music");

// 5. Objects and Prototypes
function Event(name, date, seats) {
  this.name = name;
  this.date = date;
  this.seats = seats;
}

Event.prototype.checkAvailability = function () {
  return this.seats > 0;
};

const musicEvent = new Event("Jazz Fest", "2025-07-05", 20);
console.log(musicEvent.checkAvailability());
console.log(Object.entries(musicEvent));

// 6. Arrays and Methods
let eventList = [
  { name: "Baking Workshop", category: "cooking", date: "2025-06-15" },
  { name: "Jazz Night", category: "music", date: "2025-06-20" },
  { name: "Guitar Lessons", category: "music", date: "2025-06-22" }
];

const musicEvents = eventList.filter(e => e.category === "music");
console.log(musicEvents);

const formatted = eventList.map(e => `Event: ${e.name}`);
console.log(formatted);

// 7. DOM Manipulation
const eventsContainer = document.querySelector("#events");

function renderEvents(events) {
  eventsContainer.innerHTML = "";
  events.forEach(event => {
    const card = document.createElement("div");
    card.textContent = `${event.name} - ${event.date}`;
    eventsContainer.appendChild(card);
  });
}

// 8. Event Handling
document.getElementById("categoryFilter").onchange = (e) => {
  const category = e.target.value;
  const filteredEvents = category === "all"
    ? eventList
    : filterEventsByCategory(eventList, category);
  renderEvents(filteredEvents);
};

document.getElementById("searchBox").onkeydown = (e) => {
  if (e.key === "Enter") {
    const query = e.target.value.toLowerCase();
    const results = eventList.filter(event =>
      event.name.toLowerCase().includes(query)
    );
    renderEvents(results);
  }
};

// 9. Async JS - Fetch Events
// Using .then()
fetch("events.json")
  .then(res => res.json())
  .then(data => console.log(data))
  .catch(err => console.error(err));

// Using async/await
async function fetchEvents() {
  document.getElementById("loader").style.display = "block";
  try {
    const res = await fetch("events.json");
    const data = await res.json();
    renderEvents(data);
  } catch (err) {
    console.error(err);
  } finally {
    document.getElementById("loader").style.display = "none";
  }
}

// 10. Modern JS Features
function createEvent(name, date, seats = 10) {
  return { name, date, seats };
}

const { name, date } = createEvent("Yoga", "2025-08-01");

const originalEvents = [{ name: "A" }];
const clonedEvents = [...originalEvents];

// 11. Form Handling
document.getElementById("registerForm").onsubmit = function (e) {
  e.preventDefault();

  const nameInput = e.target.elements.name;
  const emailInput = e.target.elements.email;
  const eventInput = e.target.elements.event;

  const name = nameInput.value.trim();
  const email = emailInput.value.trim();
  const selectedEvent = eventInput.value;

  if (!name || !email) {
    alert("All fields are required.");
    return;
  }

  console.log(`Registering ${name}, ${email} for ${selectedEvent}...`);

  // Simulate AJAX registration
  fetch("https://jsonplaceholder.typicode.com/posts", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name, email, event: selectedEvent }),
  })
    .then(res => {
      if (!res.ok) throw new Error("Network error");
      return res.json();
    })
    .then(data => {
      setTimeout(() => {
        alert("Registration successful!");
      }, 1000);
    })
    .catch(err => {
      alert("Failed to register. Please try again.");
      console.error(err);
    });
};


// 12. AJAX & Fetch API
// fetch("https://jsonplaceholder.typicode.com/posts", {
//   method: "POST",
//   headers: { "Content-Type": "application/json" },
//   body: JSON.stringify({ name: "Alice", event: "Yoga" }),
// })
//   .then(res => res.json())
//   .then(data => {
//     setTimeout(() => alert("Registration successful!"), 2000);
//   })
//   .catch(() => alert("Error submitting registration"));

console.log("Form submission started");

// 13. jQuery Enhancements
$(document).ready(() => {
  $('#registerBtn').click(() => {
    $('#card').fadeIn();
  });

  setTimeout(() => {
    $('#card').fadeOut();
  }, 3000);
});

// 14. Framework Mention
// Benefit of React/Vue: Component-based architecture improves reusability, testability, and scalability of the UI.
