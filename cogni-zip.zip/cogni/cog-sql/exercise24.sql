SELECT
  e.event_id,
  e.title,
  ROUND(AVG(
    (julianday(s.end_time) - julianday(s.start_time)) * 24 * 60
  ), 2) AS avg_session_duration_minutes
FROM Events e
JOIN Sessions s ON e.event_id = s.event_id
GROUP BY e.event_id, e.title
ORDER BY avg_session_duration_minutes DESC;
