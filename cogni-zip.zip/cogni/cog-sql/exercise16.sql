SELECT
  u.user_id,
  u.full_name,
  u.email,
  u.registration_date
FROM Users u
LEFT JOIN Registrations r ON u.user_id = r.user_id
WHERE
  u.registration_date >= DATE('now', '-30 days')
  AND r.user_id IS NULL;
