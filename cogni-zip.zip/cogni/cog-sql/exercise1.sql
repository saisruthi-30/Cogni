-- Upcoming events for user_id 1
SELECT
  e.event_id,
  e.title,
  e.city,
  e.start_date,
  e.end_date,
  e.status
FROM Users u
JOIN Registrations r ON u.user_id = r.user_id
JOIN Events e ON r.event_id = e.event_id
WHERE
  u.user_id = 1
  AND u.city = e.city
  AND e.status = 'upcoming'
ORDER BY e.start_date;
