SELECT
  strftime('%Y-%m', registration_date) AS registration_month,
  COUNT(*) AS registration_count
FROM Registrations
WHERE registration_date >= date('now', '-12 months')
GROUP BY registration_month
ORDER BY registration_month;
