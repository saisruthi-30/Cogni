# Cognizant Bootstrap 5 Assignment

Each folder inside `exercises/` corresponds to one section of the assignment.